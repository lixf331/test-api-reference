# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

__all__ = [
    "BadRequestError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ConflictError",
    "UnprocessableEntityError",
    "RateLimitError",
    "InternalServerError",
    "APIMappingError",
    "APIValidationError",
    "APIUserError",
    "APISystemError",
    "APIAuthError",
    "APINotFoundError",
    "APIRateLimitError",
]


class UfcloudError(Exception):
    pass


class APIError(UfcloudError):
    message: str
    request: httpx.Request

    body: object | None
    """The API response body.

    If the API responded with a valid JSON structure then this property will be the
    decoded result.

    If it isn't a valid JSON structure then this will be the raw response.

    If there was no response associated with this error then it will be `None`.
    """

    def __init__(self, message: str, request: httpx.Request, *, body: object | None) -> None:  # noqa: ARG002
        super().__init__(message)
        self.request = request
        self.message = message
        self.body = body


class APIResponseValidationError(APIError):
    response: httpx.Response
    status_code: int

    def __init__(self, response: httpx.Response, body: object | None, *, message: str | None = None) -> None:
        super().__init__(message or "Data returned by API invalid for expected schema.", response.request, body=body)
        self.response = response
        self.status_code = response.status_code


class APIStatusError(APIError):
    """Raised when an API response has a status code of 4xx or 5xx."""

    response: httpx.Response
    status_code: int

    def __init__(self, message: str, *, response: httpx.Response, body: object | None) -> None:
        super().__init__(message, response.request, body=body)
        self.response = response
        self.status_code = response.status_code


class APIMappingError(APIStatusError):
    """
    All non-2xx responses must return a JSON body:
    {
        "error": {
            "type": "validation_error | user_error | system_error | auth_error | not_found | rate_limit",
            "code": "STRING_CODE",
            "message": "Human-readable message",
            "details": {
            "...": "optional extra context"
            }
        }
    }
    If HTTP status is 4xx/5xx and body contains error: Read error.type, error.code, error.message, error.details.
        Map:
        validation_error → ValidationError
        user_error → UserError
        system_error → SystemError
        auth_error → AuthError
        not_found → NotFoundError
        rate_limit → RateLimitError
    If no error envelope and HTTP status is 4xx/5xx: Wrap as SystemError with generic code like UNKNOWN_ERROR.
    """

    type: str
    code: str | None
    details: object | None

    def __init__(
        self,
        type: str,
        code: str | None,
        message: str,
        details: object | None,
        *,
        response: httpx.Response,
        body: object | None,
    ) -> None:
        super().__init__(message, response=response, body=body)
        self.type = type
        self.code = code
        self.details = details


class APIValidationError(APIMappingError):
    pass


class APIUserError(APIMappingError):
    pass


class APISystemError(APIMappingError):
    pass


class APIAuthError(APIMappingError):
    pass


class APINotFoundError(APIMappingError):
    pass


class APIRateLimitError(APIMappingError):
    pass


class APIConnectionError(APIError):
    def __init__(self, *, message: str = "Connection error.", request: httpx.Request) -> None:
        super().__init__(message, request, body=None)


class APITimeoutError(APIConnectionError):
    def __init__(self, request: httpx.Request) -> None:
        super().__init__(message="Request timed out.", request=request)


class BadRequestError(APIStatusError):
    status_code: Literal[400] = 400  # pyright: ignore[reportIncompatibleVariableOverride]


class AuthenticationError(APIStatusError):
    status_code: Literal[401] = 401  # pyright: ignore[reportIncompatibleVariableOverride]


class PermissionDeniedError(APIStatusError):
    status_code: Literal[403] = 403  # pyright: ignore[reportIncompatibleVariableOverride]


class NotFoundError(APIStatusError):
    status_code: Literal[404] = 404  # pyright: ignore[reportIncompatibleVariableOverride]


class ConflictError(APIStatusError):
    status_code: Literal[409] = 409  # pyright: ignore[reportIncompatibleVariableOverride]


class UnprocessableEntityError(APIStatusError):
    status_code: Literal[422] = 422  # pyright: ignore[reportIncompatibleVariableOverride]


class RateLimitError(APIStatusError):
    status_code: Literal[429] = 429  # pyright: ignore[reportIncompatibleVariableOverride]


class InternalServerError(APIStatusError):
    pass

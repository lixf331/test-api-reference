# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from . import shared, response_create_response
from .. import _compat
from .shared import CompoundFilter as CompoundFilter
from .rerank_create_params import RerankCreateParams as RerankCreateParams
from .rerank_create_response import RerankCreateResponse as RerankCreateResponse
from .response_create_params import ResponseCreateParams as ResponseCreateParams
from .embedding_create_params import EmbeddingCreateParams as EmbeddingCreateParams
from .fine_tuning_list_params import FineTuningListParams as FineTuningListParams
from .file_preprocess_response import FilePreprocessResponse as FilePreprocessResponse
from .response_create_response import ResponseCreateResponse as ResponseCreateResponse
from .embedding_create_response import EmbeddingCreateResponse as EmbeddingCreateResponse
from .fine_tuning_create_params import FineTuningCreateParams as FineTuningCreateParams
from .fine_tuning_list_response import FineTuningListResponse as FineTuningListResponse
from .file_presigned_post_params import FilePresignedPostParams as FilePresignedPostParams
from .fine_tuning_create_response import FineTuningCreateResponse as FineTuningCreateResponse
from .file_presigned_post_response import FilePresignedPostResponse as FilePresignedPostResponse
from .fine_tuning_retrieve_response import FineTuningRetrieveResponse as FineTuningRetrieveResponse
from .fine_tuning_download_adapter_params import FineTuningDownloadAdapterParams as FineTuningDownloadAdapterParams

# Rebuild cyclical models only after all modules are imported.
# This ensures that, when building the deferred (due to cyclical references) model schema,
# Pydantic can resolve the necessary references.
# See: https://github.com/pydantic/pydantic/issues/11250 for more context.
if _compat.PYDANTIC_V1:
    response_create_response.ResponseCreateResponse.update_forward_refs()  # type: ignore
    shared.compound_filter.CompoundFilter.update_forward_refs()  # type: ignore
else:
    response_create_response.ResponseCreateResponse.model_rebuild(_parent_namespace_depth=0)
    shared.compound_filter.CompoundFilter.model_rebuild(_parent_namespace_depth=0)

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["FunctionCallParam"]


class FunctionCallParam(TypedDict, total=False):
    """Deprecated function call information."""

    arguments: Required[str]

    name: Required[str]

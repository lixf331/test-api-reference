# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .compound_filter import CompoundFilter as CompoundFilter

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import TYPE_CHECKING, List, Union
from typing_extensions import Literal, TypeAlias, TypeAliasType

from ..._compat import PYDANTIC_V1
from ..._models import BaseModel

__all__ = ["CompoundFilter", "Filter", "FilterComparisonFilter"]


class FilterComparisonFilter(BaseModel):
    """
    A filter used to compare a specified attribute key to a given value using a defined comparison operation.
    """

    key: str
    """The key to compare against the value."""

    type: Literal["eq", "ne", "gt", "gte", "lt", "lte"]
    """
    Specifies the comparison operator: `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`,
    `nin`.
    """

    value: Union[str, float, bool, List[Union[str, float]]]
    """
    The value to compare against the attribute key; supports string, number, or
    boolean types.
    """


if TYPE_CHECKING or not PYDANTIC_V1:
    Filter = TypeAliasType("Filter", Union[FilterComparisonFilter, "CompoundFilter"])
else:
    Filter: TypeAlias = Union[FilterComparisonFilter, "CompoundFilter"]


class CompoundFilter(BaseModel):
    """Combine multiple filters using `and` or `or`."""

    filters: List[Filter]
    """Array of filters to combine.

    Items can be `ComparisonFilter` or `CompoundFilter`.
    """

    type: Literal["and", "or"]
    """Type of operation: `and` or `or`."""

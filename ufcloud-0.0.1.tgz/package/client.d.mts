import type { RequestInit, RequestInfo } from "./internal/builtin-types.mjs";
import type { PromiseOrValue, MergedRequestInit, FinalizedRequestInit } from "./internal/types.mjs";
export type { Logger, LogLevel } from "./internal/utils/log.mjs";
import * as Opts from "./internal/request-options.mjs";
import * as Errors from "./core/error.mjs";
import * as Pagination from "./core/pagination.mjs";
import { AbstractPage, PagePromise, type OffsetPaginationParams, OffsetPaginationResponse } from "./core/pagination.mjs";
import * as Uploads from "./core/uploads.mjs";
import * as API from "./resources/index.mjs";
import { APIPromise } from "./core/api-promise.mjs";
import { EmbeddingCreateParams, EmbeddingCreateResponse, Embeddings } from "./resources/embeddings.mjs";
import { FilePreprocessResponse, FilePresignedPostParams, FilePresignedPostResponse, Files } from "./resources/files.mjs";
import { Rerank, RerankCreateParams, RerankCreateResponse } from "./resources/rerank.mjs";
import { ResponseCreateParams, ResponseCreateResponse, Responses } from "./resources/responses.mjs";
import { Chat } from "./resources/chat/chat.mjs";
import { FineTuning, FineTuningCreateParams, FineTuningCreateResponse, FineTuningDownloadAdapterParams, FineTuningListParams, FineTuningListResponse, FineTuningListResponsesOffsetPagination, FineTuningRetrieveResponse } from "./resources/fine-tuning/fine-tuning.mjs";
import { type Fetch } from "./internal/builtin-types.mjs";
import { HeadersLike, NullableHeaders } from "./internal/headers.mjs";
import { FinalRequestOptions, RequestOptions } from "./internal/request-options.mjs";
import { type LogLevel, type Logger } from "./internal/utils/log.mjs";
export interface ClientOptions {
    /**
     * Defaults to process.env['UFCLOUD_API_KEY'].
     */
    apiKey?: string | undefined;
    /**
     * Override the default base URL for the API, e.g., "https://api.example.com/v2/"
     *
     * Defaults to process.env['UFCLOUD_BASE_URL'].
     */
    baseURL?: string | null | undefined;
    /**
     * The maximum amount of time (in milliseconds) that the client should wait for a response
     * from the server before timing out a single request.
     *
     * Note that request timeouts are retried by default, so in a worst-case scenario you may wait
     * much longer than this timeout before the promise succeeds or fails.
     *
     * @unit milliseconds
     */
    timeout?: number | undefined;
    /**
     * Additional `RequestInit` options to be passed to `fetch` calls.
     * Properties will be overridden by per-request `fetchOptions`.
     */
    fetchOptions?: MergedRequestInit | undefined;
    /**
     * Specify a custom `fetch` function implementation.
     *
     * If not provided, we expect that `fetch` is defined globally.
     */
    fetch?: Fetch | undefined;
    /**
     * The maximum number of times that the client will retry a request in case of a
     * temporary failure, like a network error or a 5XX error from the server.
     *
     * @default 2
     */
    maxRetries?: number | undefined;
    /**
     * Default headers to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * header to `null` in request options.
     */
    defaultHeaders?: HeadersLike | undefined;
    /**
     * Default query parameters to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * param to `undefined` in request options.
     */
    defaultQuery?: Record<string, string | undefined> | undefined;
    /**
     * Set the log level.
     *
     * Defaults to process.env['UFCLOUD_LOG'] or 'warn' if it isn't set.
     */
    logLevel?: LogLevel | undefined;
    /**
     * Set the logger.
     *
     * Defaults to globalThis.console.
     */
    logger?: Logger | undefined;
}
/**
 * API Client for interfacing with the Ufcloud API.
 */
export declare class Ufcloud {
    #private;
    apiKey: string;
    baseURL: string;
    maxRetries: number;
    timeout: number;
    logger: Logger;
    logLevel: LogLevel | undefined;
    fetchOptions: MergedRequestInit | undefined;
    private fetch;
    protected idempotencyHeader?: string;
    private _options;
    /**
     * API Client for interfacing with the Ufcloud API.
     *
     * @param {string | undefined} [opts.apiKey=process.env['UFCLOUD_API_KEY'] ?? undefined]
     * @param {string} [opts.baseURL=process.env['UFCLOUD_BASE_URL'] ?? https://api.ufcloud.ai] - Override the default base URL for the API.
     * @param {number} [opts.timeout=1 minute] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
     * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
     */
    constructor({ baseURL, apiKey, ...opts }?: ClientOptions);
    /**
     * Create a new client instance re-using the same options given to the current client with optional overriding.
     */
    withOptions(options: Partial<ClientOptions>): this;
    protected defaultQuery(): Record<string, string | undefined> | undefined;
    protected validateHeaders({ values, nulls }: NullableHeaders): void;
    protected authHeaders(opts: FinalRequestOptions): Promise<NullableHeaders | undefined>;
    /**
     * Basic re-implementation of `qs.stringify` for primitive types.
     */
    protected stringifyQuery(query: Record<string, unknown>): string;
    private getUserAgent;
    protected defaultIdempotencyKey(): string;
    protected makeStatusError(status: number, error: Object, message: string | undefined, headers: Headers): Errors.APIError;
    buildURL(path: string, query: Record<string, unknown> | null | undefined, defaultBaseURL?: string | undefined): string;
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    protected prepareOptions(options: FinalRequestOptions): Promise<void>;
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     */
    protected prepareRequest(request: RequestInit, { url, options }: {
        url: string;
        options: FinalRequestOptions;
    }): Promise<void>;
    get<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    post<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    patch<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    put<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    delete<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    private methodRequest;
    request<Rsp>(options: PromiseOrValue<FinalRequestOptions>, remainingRetries?: number | null): APIPromise<Rsp>;
    private makeRequest;
    getAPIList<Item, PageClass extends AbstractPage<Item> = AbstractPage<Item>>(path: string, Page: new (...args: any[]) => PageClass, opts?: RequestOptions): PagePromise<PageClass, Item>;
    requestAPIList<Item = unknown, PageClass extends AbstractPage<Item> = AbstractPage<Item>>(Page: new (...args: ConstructorParameters<typeof AbstractPage>) => PageClass, options: FinalRequestOptions): PagePromise<PageClass, Item>;
    fetchWithTimeout(url: RequestInfo, init: RequestInit | undefined, ms: number, controller: AbortController): Promise<Response>;
    private shouldRetry;
    private retryRequest;
    private calculateDefaultRetryTimeoutMillis;
    buildRequest(inputOptions: FinalRequestOptions, { retryCount }?: {
        retryCount?: number;
    }): Promise<{
        req: FinalizedRequestInit;
        url: string;
        timeout: number;
    }>;
    private buildHeaders;
    private buildBody;
    static Ufcloud: typeof Ufcloud;
    static DEFAULT_TIMEOUT: number;
    static UfcloudError: typeof Errors.UfcloudError;
    static APIError: typeof Errors.APIError;
    static APIConnectionError: typeof Errors.APIConnectionError;
    static APIConnectionTimeoutError: typeof Errors.APIConnectionTimeoutError;
    static APIUserAbortError: typeof Errors.APIUserAbortError;
    static NotFoundError: typeof Errors.NotFoundError;
    static ConflictError: typeof Errors.ConflictError;
    static RateLimitError: typeof Errors.RateLimitError;
    static BadRequestError: typeof Errors.BadRequestError;
    static AuthenticationError: typeof Errors.AuthenticationError;
    static InternalServerError: typeof Errors.InternalServerError;
    static PermissionDeniedError: typeof Errors.PermissionDeniedError;
    static UnprocessableEntityError: typeof Errors.UnprocessableEntityError;
    static APIMappingError: typeof Errors.APIMappingError;
    static APIValidationError: typeof Errors.APIValidationError;
    static APIUserError: typeof Errors.APIUserError;
    static APISystemError: typeof Errors.APISystemError;
    static APIAuthError: typeof Errors.APIAuthError;
    static APINotFoundError: typeof Errors.APINotFoundError;
    static APIRateLimitError: typeof Errors.APIRateLimitError;
    static toFile: typeof Uploads.toFile;
    chat: API.Chat;
    embeddings: API.Embeddings;
    rerank: API.Rerank;
    files: API.Files;
    fineTuning: API.FineTuning;
    responses: API.Responses;
}
export declare namespace Ufcloud {
    export type RequestOptions = Opts.RequestOptions;
    export import OffsetPagination = Pagination.OffsetPagination;
    export { type OffsetPaginationParams as OffsetPaginationParams, type OffsetPaginationResponse as OffsetPaginationResponse, };
    export { Chat as Chat };
    export { Embeddings as Embeddings, type EmbeddingCreateResponse as EmbeddingCreateResponse, type EmbeddingCreateParams as EmbeddingCreateParams, };
    export { Rerank as Rerank, type RerankCreateResponse as RerankCreateResponse, type RerankCreateParams as RerankCreateParams, };
    export { Files as Files, type FilePreprocessResponse as FilePreprocessResponse, type FilePresignedPostResponse as FilePresignedPostResponse, type FilePresignedPostParams as FilePresignedPostParams, };
    export { FineTuning as FineTuning, type FineTuningCreateResponse as FineTuningCreateResponse, type FineTuningRetrieveResponse as FineTuningRetrieveResponse, type FineTuningListResponse as FineTuningListResponse, type FineTuningListResponsesOffsetPagination as FineTuningListResponsesOffsetPagination, type FineTuningCreateParams as FineTuningCreateParams, type FineTuningListParams as FineTuningListParams, type FineTuningDownloadAdapterParams as FineTuningDownloadAdapterParams, };
    export { Responses as Responses, type ResponseCreateResponse as ResponseCreateResponse, type ResponseCreateParams as ResponseCreateParams, };
    export type CompoundFilter = API.CompoundFilter;
}
//# sourceMappingURL=client.d.mts.map
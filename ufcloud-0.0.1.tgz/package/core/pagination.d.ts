import { FinalRequestOptions } from "../internal/request-options.js";
import { type Ufcloud } from "../client.js";
import { APIPromise } from "./api-promise.js";
import { type APIResponseProps } from "../internal/parse.js";
export type PageRequestOptions = Pick<FinalRequestOptions, 'query' | 'headers' | 'body' | 'path' | 'method'>;
export declare abstract class AbstractPage<Item> implements AsyncIterable<Item> {
    #private;
    protected options: FinalRequestOptions;
    protected response: Response;
    protected body: unknown;
    constructor(client: Ufcloud, response: Response, body: unknown, options: FinalRequestOptions);
    abstract nextPageRequestOptions(): PageRequestOptions | null;
    abstract getPaginatedItems(): Item[];
    hasNextPage(): boolean;
    getNextPage(): Promise<this>;
    iterPages(): AsyncGenerator<this>;
    [Symbol.asyncIterator](): AsyncGenerator<Item>;
}
/**
 * This subclass of Promise will resolve to an instantiated Page once the request completes.
 *
 * It also implements AsyncIterable to allow auto-paginating iteration on an unawaited list call, eg:
 *
 *    for await (const item of client.items.list()) {
 *      console.log(item)
 *    }
 */
export declare class PagePromise<PageClass extends AbstractPage<Item>, Item = ReturnType<PageClass['getPaginatedItems']>[number]> extends APIPromise<PageClass> implements AsyncIterable<Item> {
    constructor(client: Ufcloud, request: Promise<APIResponseProps>, Page: new (...args: ConstructorParameters<typeof AbstractPage>) => PageClass);
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    [Symbol.asyncIterator](): AsyncGenerator<Item>;
}
export interface OffsetPaginationResponse<Item> {
    data: Array<Item>;
    has_next: boolean;
    /** True if more pages exist */
    limit: number;
    /** Items per page */
    page: number;
    /** Current page number (1-based) */
    count?: number | null;
    /** Count of items returned so far */
    total?: number | null;
}
export interface OffsetPaginationParams {
    /**
     * Page number, 1-based
     */
    page?: number;
    /**
     * The maximum number of elements to fetch.
     */
    limit?: number;
}
export declare class OffsetPagination<Item> extends AbstractPage<Item> implements OffsetPaginationResponse<Item> {
    data: Array<Item>;
    has_next: boolean;
    limit: number;
    page: number;
    count?: number | null;
    total?: number | null;
    constructor(client: Ufcloud, response: Response, body: OffsetPaginationResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    hasNextPage(): boolean;
    nextPageRequestOptions(): PageRequestOptions | null;
}
//# sourceMappingURL=pagination.d.ts.map
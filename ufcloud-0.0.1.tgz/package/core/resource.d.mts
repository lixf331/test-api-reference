import type { Ufcloud } from "../client.mjs";
export declare abstract class APIResource {
    protected _client: Ufcloud;
    constructor(client: Ufcloud);
}
//# sourceMappingURL=resource.d.mts.map
import { APIResource } from "../../core/resource.mjs";
import * as CompletionsAPI from "./completions.mjs";
import { ChatCompletionContentPartTextParam, ChatCompletionLogProb, CompletionCreateParams, CompletionCreateResponse, Completions, FunctionCall } from "./completions.mjs";
export declare class Chat extends APIResource {
    completions: CompletionsAPI.Completions;
}
export declare namespace Chat {
    export { Completions as Completions, type ChatCompletionContentPartTextParam as ChatCompletionContentPartTextParam, type ChatCompletionLogProb as ChatCompletionLogProb, type FunctionCall as FunctionCall, type CompletionCreateResponse as CompletionCreateResponse, type CompletionCreateParams as CompletionCreateParams, };
}
//# sourceMappingURL=chat.d.mts.map
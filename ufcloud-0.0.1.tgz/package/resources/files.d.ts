import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Files extends APIResource {
    /**
     * Trigger JSONL file validation/preprocessing.
     */
    preprocess(fileID: string, options?: RequestOptions): APIPromise<FilePreprocessResponse>;
    /**
     * Generates a presigned POST request for securely uploading files directly to S3
     * from a client.
     */
    presignedPost(params: FilePresignedPostParams, options?: RequestOptions): APIPromise<FilePresignedPostResponse>;
}
export interface FilePreprocessResponse {
    file: FilePreprocessResponse.File;
}
export declare namespace FilePreprocessResponse {
    interface File {
        created_at: string;
        file_id: string;
        filename: string;
        purpose: string;
        status: 'pending' | 'processed';
        updated_at: string;
        line_count?: number | null;
        schema_type?: 'messages' | 'instruction' | null;
        size_bytes?: number | null;
    }
}
export type FilePresignedPostResponse = FilePresignedPostResponse.FineTunePresignedPostResponse | FilePresignedPostResponse.GenericPresignedPostResponse;
export declare namespace FilePresignedPostResponse {
    interface FineTunePresignedPostResponse {
        file: FineTunePresignedPostResponse.File;
        upload: FineTunePresignedPostResponse.Upload;
    }
    namespace FineTunePresignedPostResponse {
        interface File {
            created_at: string;
            file_id: string;
            filename: string;
            purpose: string;
            status: 'pending' | 'processed';
            updated_at: string;
            line_count?: number | null;
            schema_type?: 'messages' | 'instruction' | null;
            size_bytes?: number | null;
        }
        interface Upload {
            fields: Upload.Fields;
            headers: Upload.Headers;
            method: 'POST';
            url: string;
        }
        namespace Upload {
            interface Fields {
                AWSAccessKeyId?: string;
                'Content-Type'?: string;
                key?: string;
                policy?: string;
                signature?: string;
                'x-amz-security-token'?: string | null;
                [k: string]: unknown;
            }
            interface Headers {
                'Content-Type'?: string;
            }
        }
    }
    interface GenericPresignedPostResponse {
        content_type: string;
        expires_in: 3600;
        fields: {
            [key: string]: unknown;
        };
        filename: string;
        requested_at: string;
        status: 'PresignedPostGenerated';
        purpose?: string | null;
    }
}
export interface FilePresignedPostParams {
    content_type: string;
    file_name: string;
    purpose?: string | null;
}
export declare namespace Files {
    export { type FilePreprocessResponse as FilePreprocessResponse, type FilePresignedPostResponse as FilePresignedPostResponse, type FilePresignedPostParams as FilePresignedPostParams, };
}
//# sourceMappingURL=files.d.ts.map
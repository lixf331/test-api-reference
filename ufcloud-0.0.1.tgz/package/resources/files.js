"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Files = void 0;
const resource_1 = require("../core/resource.js");
const path_1 = require("../internal/utils/path.js");
class Files extends resource_1.APIResource {
    /**
     * Trigger JSONL file validation/preprocessing.
     */
    preprocess(fileID, options) {
        return this._client.post((0, path_1.path) `/v1/files/${fileID}/preprocess`, options);
    }
    /**
     * Generates a presigned POST request for securely uploading files directly to S3
     * from a client.
     */
    presignedPost(params, options) {
        const { content_type, file_name, purpose } = params;
        return this._client.post('/v1/files/presigned-post', {
            query: { content_type, file_name, purpose },
            ...options,
        });
    }
}
exports.Files = Files;
//# sourceMappingURL=files.js.map
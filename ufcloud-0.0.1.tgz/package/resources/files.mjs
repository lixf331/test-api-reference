// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { path } from "../internal/utils/path.mjs";
export class Files extends APIResource {
    /**
     * Trigger JSONL file validation/preprocessing.
     */
    preprocess(fileID, options) {
        return this._client.post(path `/v1/files/${fileID}/preprocess`, options);
    }
    /**
     * Generates a presigned POST request for securely uploading files directly to S3
     * from a client.
     */
    presignedPost(params, options) {
        const { content_type, file_name, purpose } = params;
        return this._client.post('/v1/files/presigned-post', {
            query: { content_type, file_name, purpose },
            ...options,
        });
    }
}
//# sourceMappingURL=files.mjs.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import { castToError } from '../internal/errors';

export class UfcloudError extends Error {}

export class APIError<
  TStatus extends number | undefined = number | undefined,
  THeaders extends Headers | undefined = Headers | undefined,
  TError extends Object | undefined = Object | undefined,
> extends UfcloudError {
  /** HTTP status for the response that caused the error */
  readonly status: TStatus;
  /** HTTP headers for the response that caused the error */
  readonly headers: THeaders;
  /** JSON body of the response that caused the error */
  readonly error: TError;

  constructor(status: TStatus, error: TError, message: string | undefined, headers: THeaders) {
    super(`${APIError.makeMessage(status, error, message)}`);
    this.status = status;
    this.headers = headers;
    this.error = error;
  }

  private static makeMessage(status: number | undefined, error: any, message: string | undefined) {
    // 1. If we already have a parsed message from the error envelope, use it directly (no status prefix).
    if (message) {
      return message;
    }

    // 2. Otherwise, fall back to error.message or serialized error.
    const fallback =
      error?.message ?
        typeof error.message === 'string' ?
          error.message
        : JSON.stringify(error.message)
      : error ? JSON.stringify(error)
      : undefined;

    // 3. If we have both status and some fallback text, keep old "status + text" behaviour.
    if (status && fallback) {
      return `${status} ${fallback}`;
    }
    if (status) {
      return `${status} status code (no body)`;
    }
    if (fallback) {
      return fallback;
    }
    return '(no status code or body)';
  }

  static generate(
    status: number | undefined,
    errorResponse: Object | undefined,
    message: string | undefined,
    headers: Headers | undefined,
  ): APIError {
    if (!status || !headers) {
      return new APIConnectionError({ message, cause: castToError(errorResponse) });
    }

    const error = errorResponse as Record<string, any>;

    // if (status === 400) {
    //   return new BadRequestError(status, error, message, headers);
    // }

    // if (status === 401) {
    //   return new AuthenticationError(status, error, message, headers);
    // }

    // if (status === 403) {
    //   return new PermissionDeniedError(status, error, message, headers);
    // }

    // if (status === 404) {
    //   return new NotFoundError(status, error, message, headers);
    // }

    // if (status === 409) {
    //   return new ConflictError(status, error, message, headers);
    // }

    // if (status === 422) {
    //   return new UnprocessableEntityError(status, error, message, headers);
    // }

    // if (status === 429) {
    //   return new RateLimitError(status, error, message, headers);
    // }

    // if (status >= 500) {
    //   return new InternalServerError(status, error, message, headers);
    // }

    // return new APIError(status, error, message, headers);

    // Extract error information from response body
    const errorInfo = extractErrorInfo(error, message, status);

    // Get the appropriate exception class based on error type
    const ExceptionClass = ERROR_TYPE_TO_CLASS[errorInfo.type] || APISystemError;

    return new ExceptionClass(
      errorInfo.type,
      errorInfo.code,
      errorInfo.message,
      errorInfo.details,
      status,
      error,
      headers,
    );
  }
}

interface ErrorInfo {
  type: string;
  code: string | null;
  message: string;
  details: object | null;
}

/**
 * Extract error information from response body.
 *
 * Returns error type, code, message, and details.
 */
function extractErrorInfo(
  body: object | undefined,
  errMsg: string | undefined,
  statusCode: number,
): ErrorInfo {
  // Extract error information from body if available
  // Try to extract from standard format: {"error": {"type": ..., "code": ..., "message": ..., "details": ...}}
  let errorData: Record<string, any> = {};
  let fallbackMessage: string | null = null;

  if (body && typeof body === 'object' && !Array.isArray(body)) {
    const bodyDict = body as Record<string, any>;
    const errorObj = bodyDict['error'];

    if (errorObj && typeof errorObj === 'object' && !Array.isArray(errorObj)) {
      // Standard format: {"error": {...}}
      errorData = errorObj as Record<string, any>;
    } else {
      // Non-standard format: try to extract from common fields
      // Check for common error message fields: detail, message, error (as string)
      if ('detail' in bodyDict) {
        const detailValue = bodyDict['detail'];
        if (typeof detailValue === 'string') {
          fallbackMessage = detailValue;
        } else {
          // Convert list, dict, or other types to string representation
          fallbackMessage = String(detailValue);
        }
      } else if ('message' in bodyDict && typeof bodyDict['message'] === 'string') {
        fallbackMessage = bodyDict['message'];
      } else if ('error' in bodyDict && typeof bodyDict['error'] === 'string') {
        fallbackMessage = bodyDict['error'];
      } else if (Object.keys(bodyDict).length > 0) {
        // If body has other fields, use the whole body as details
        fallbackMessage = JSON.stringify(bodyDict);
      }
    }
  }

  // Extract error type as string
  let errorTypeStr: string | null = errorData['type'];
  let errorType: string;
  if (
    errorTypeStr &&
    ['validation_error', 'user_error', 'system_error', 'auth_error', 'not_found', 'rate_limit'].includes(
      errorTypeStr,
    )
  ) {
    errorType = errorTypeStr;
  } else {
    errorType = 'unknown_error';
  }

  // Extract error code, message, and details
  // Safely convert code to string if it exists and is not already a string
  const codeValue = errorData['code'];
  const errorCode: string | null = codeValue != null ? String(codeValue) : null;

  const errorMessageRaw: string | null = errorData['message'];
  const errorDetails: object | null = errorData['details'] || null;

  // Use error message from standard format, fallback to extracted message, or use errMsg
  let errorMessage: string;
  if (errorMessageRaw && typeof errorMessageRaw === 'string' && errorMessageRaw) {
    errorMessage = errorMessageRaw;
  } else if (fallbackMessage) {
    errorMessage = fallbackMessage;
  } else {
    errorMessage = errMsg || 'Unknown error';
  }

  // Handle special status codes (401/403) - force auth_error type
  if (statusCode === 401 || statusCode === 403) {
    errorType = 'auth_error';
  }

  return {
    type: errorType,
    code: errorCode,
    message: errorMessage,
    details: errorDetails,
  };
}

export class APIUserAbortError extends APIError<undefined, undefined, undefined> {
  constructor({ message }: { message?: string } = {}) {
    super(undefined, undefined, message || 'Request was aborted.', undefined);
  }
}

export class APIConnectionError extends APIError<undefined, undefined, undefined> {
  constructor({ message, cause }: { message?: string | undefined; cause?: Error | undefined }) {
    super(undefined, undefined, message || 'Connection error.', undefined);
    // in some environments the 'cause' property is already declared
    // @ts-ignore
    if (cause) this.cause = cause;
  }
}

export class APIConnectionTimeoutError extends APIConnectionError {
  constructor({ message }: { message?: string } = {}) {
    super({ message: message ?? 'Request timed out.' });
  }
}

/**
 * Base class for API mapping errors that contain error type, code, and details.
 */
export class APIMappingError extends APIError<number, Headers> {
  readonly type: string;
  readonly code: string | null;
  readonly details: object | null;

  constructor(
    type: string,
    code: string | null,
    message: string,
    details: object | null,
    status: number,
    error: Object | undefined,
    headers: Headers,
  ) {
    super(status, error, message, headers);
    this.type = type;
    this.code = code;
    this.details = details;
  }
}

export class APIValidationError extends APIMappingError {}
export class APIUserError extends APIMappingError {}
export class APISystemError extends APIMappingError {}
export class APIAuthError extends APIMappingError {}
export class APINotFoundError extends APIMappingError {}
export class APIRateLimitError extends APIMappingError {}

/**
 * Map error types to exception classes
 */
const ERROR_TYPE_TO_CLASS: Record<string, new (...args: any[]) => APIMappingError> = {
  validation_error: APIValidationError,
  user_error: APIUserError,
  system_error: APISystemError,
  auth_error: APIAuthError,
  not_found: APINotFoundError,
  rate_limit: APIRateLimitError,
  unknown_error: APISystemError,
};

export class BadRequestError extends APIError<400, Headers> {}

export class AuthenticationError extends APIError<401, Headers> {}

export class PermissionDeniedError extends APIError<403, Headers> {}

export class NotFoundError extends APIError<404, Headers> {}

export class ConflictError extends APIError<409, Headers> {}

export class UnprocessableEntityError extends APIError<422, Headers> {}

export class RateLimitError extends APIError<429, Headers> {}

export class InternalServerError extends APIError<number, Headers> {}

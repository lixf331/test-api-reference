// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import { APIResource } from '../core/resource';
import { APIPromise } from '../core/api-promise';
import { RequestOptions } from '../internal/request-options';
import { path } from '../internal/utils/path';

export class Files extends APIResource {
  /**
   * Trigger JSONL file validation/preprocessing.
   */
  preprocess(fileID: string, options?: RequestOptions): APIPromise<FilePreprocessResponse> {
    return this._client.post(path`/v1/files/${fileID}/preprocess`, options);
  }

  /**
   * Generates a presigned POST request for securely uploading files directly to S3
   * from a client.
   */
  presignedPost(
    params: FilePresignedPostParams,
    options?: RequestOptions,
  ): APIPromise<FilePresignedPostResponse> {
    const { content_type, file_name, purpose } = params;
    return this._client.post('/v1/files/presigned-post', {
      query: { content_type, file_name, purpose },
      ...options,
    });
  }
}

export interface FilePreprocessResponse {
  file: FilePreprocessResponse.File;
}

export namespace FilePreprocessResponse {
  export interface File {
    created_at: string;

    file_id: string;

    filename: string;

    purpose: string;

    status: 'pending' | 'processed';

    updated_at: string;

    line_count?: number | null;

    schema_type?: 'messages' | 'instruction' | null;

    size_bytes?: number | null;
  }
}

export type FilePresignedPostResponse =
  | FilePresignedPostResponse.FineTunePresignedPostResponse
  | FilePresignedPostResponse.GenericPresignedPostResponse;

export namespace FilePresignedPostResponse {
  export interface FineTunePresignedPostResponse {
    file: FineTunePresignedPostResponse.File;

    upload: FineTunePresignedPostResponse.Upload;
  }

  export namespace FineTunePresignedPostResponse {
    export interface File {
      created_at: string;

      file_id: string;

      filename: string;

      purpose: string;

      status: 'pending' | 'processed';

      updated_at: string;

      line_count?: number | null;

      schema_type?: 'messages' | 'instruction' | null;

      size_bytes?: number | null;
    }

    export interface Upload {
      fields: Upload.Fields;

      headers: Upload.Headers;

      method: 'POST';

      url: string;
    }

    export namespace Upload {
      export interface Fields {
        AWSAccessKeyId?: string;

        'Content-Type'?: string;

        key?: string;

        policy?: string;

        signature?: string;

        'x-amz-security-token'?: string | null;

        [k: string]: unknown;
      }

      export interface Headers {
        'Content-Type'?: string;
      }
    }
  }

  export interface GenericPresignedPostResponse {
    content_type: string;

    expires_in: 3600;

    fields: { [key: string]: unknown };

    filename: string;

    requested_at: string;

    status: 'PresignedPostGenerated';

    purpose?: string | null;
  }
}

export interface FilePresignedPostParams {
  content_type: string;

  file_name: string;

  purpose?: string | null;
}

export declare namespace Files {
  export {
    type FilePreprocessResponse as FilePreprocessResponse,
    type FilePresignedPostResponse as FilePresignedPostResponse,
    type FilePresignedPostParams as FilePresignedPostParams,
  };
}
